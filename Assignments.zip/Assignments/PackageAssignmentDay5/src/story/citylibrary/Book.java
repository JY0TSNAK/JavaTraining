package story.citylibrary;

public class Book {
	int bookId;
	String bookName;
}
