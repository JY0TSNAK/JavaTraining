package story.citylibrary;

import story.people.Person;

public class Library {
private static int booksAvailableToBorrow = 100; //static //private	
	public int borrowBook(Book bookObj, Person p) {
		int booksRemaining;
		System.out.println(p.name + " borrowed book to read");
		booksAvailableToBorrow--;
		booksRemaining = booksAvailableToBorrow;
		return booksRemaining;

	}
}
