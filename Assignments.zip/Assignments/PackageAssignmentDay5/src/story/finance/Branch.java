package story.finance;

class Branch {
	Account openAccount(int acctNum, String acctHolderName) {
		Account acctObj = new Account(acctNum, acctHolderName);
		return acctObj;
	}
}
