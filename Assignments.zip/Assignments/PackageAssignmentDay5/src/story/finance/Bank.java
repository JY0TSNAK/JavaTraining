package story.finance;

class Bank {
	Branch openBranch() {
		Branch branchObj = new Branch();
		return branchObj;
	}
}
