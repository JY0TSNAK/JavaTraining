package story.finance;

class Account {
	protected int acctNum; //protected
	String acctHolderName; //default
	public Account(int acctNum, String acctHolderName) {
		super();
		this.acctNum = acctNum;
		this.acctHolderName = acctHolderName;
	}
}
