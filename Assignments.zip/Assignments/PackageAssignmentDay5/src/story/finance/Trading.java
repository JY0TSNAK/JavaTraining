package story.finance;

public class Trading {
	DematAccount da;
	int StockId;
	float price;
	public Trading(DematAccount da, int stockId, float price) {
		super();
		this.da = da;
		StockId = stockId;
		this.price = price;
		System.out.println(da.acctHolderName + " does trading in account " + da.acctNum);
	}
}
