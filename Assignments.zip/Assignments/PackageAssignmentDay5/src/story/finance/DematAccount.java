package story.finance;

public class DematAccount extends Account {
	public DematAccount(int acctNum, String acctHolderName) {
		super(acctNum, acctHolderName);
		// TODO Auto-generated constructor stub
	}
}
