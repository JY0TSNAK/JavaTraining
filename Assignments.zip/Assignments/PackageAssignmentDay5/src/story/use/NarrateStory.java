package story.use;

import story.citylibrary.Book;
import story.citylibrary.Library;
import story.finance.DematAccount;
import story.finance.Trading;
import story.industry.AirConditioner;
import story.industry.AirConditionerCompany;
import story.industry.RawMaterial;
import story.industry.ReportCard;
import story.industry.Revenue;
import story.transport.TwoWheeler;

public class NarrateStory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AirConditionerCompany airCondComObj = new AirConditionerCompany();
		airCondComObj.setOwner("Aparna");
		
		RawMaterial rm = new RawMaterial();
		System.out.println("Total numer of Air Conditioners manufactured : " + AirConditionerCompany.totalNumberofACs);
		AirConditioner airConObj1 = airCondComObj.manufactures(rm);
		AirConditioner airConObj2 = airCondComObj.manufactures(rm);
		System.out.println("Total numer of Air Conditioners manufactured : " + AirConditionerCompany.totalNumberofACs);
		
		Revenue r = airCondComObj.saleofAirConditionesr();
		
		ReportCard rc = airCondComObj.getFeedback(airConObj1);
		
		DematAccount daNum = new DematAccount(123, airCondComObj.ownerObj.name);
		Trading t = new Trading(daNum, 456, 500.0f);
		
		Library l = new Library();
		Book b = new Book();
		int booksRemaining = l.borrowBook(b, airCondComObj.ownerObj);
		System.out.println("Available number books in library : " + booksRemaining);
		
		TwoWheeler tw = new TwoWheeler();
		tw.alertDriving(tw, airCondComObj.ownerObj.name);
		
		//KFC kfcObj = new KFC();
		//Food f = kfcObj.buyKFCFood();
		
		
		//Toy newToy = new Toy();
		//Shirt newShirt = new Shirt();

	}

}
