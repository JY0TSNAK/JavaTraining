package story.people;

public class Owner extends Person {

}
