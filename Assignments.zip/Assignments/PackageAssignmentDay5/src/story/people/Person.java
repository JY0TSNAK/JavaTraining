package story.people;

public class Person extends Human {
	public String name;
}
