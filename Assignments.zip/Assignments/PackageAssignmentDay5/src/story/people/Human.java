package story.people;

abstract class Human extends Mammal{ //abstract

}
