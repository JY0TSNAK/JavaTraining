package story.people;

public class Customer extends Person {
	int customerId;
}
