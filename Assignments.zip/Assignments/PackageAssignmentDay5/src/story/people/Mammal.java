package story.people;

class Mammal {

}
