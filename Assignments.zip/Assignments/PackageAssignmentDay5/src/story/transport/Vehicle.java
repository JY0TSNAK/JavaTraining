package story.transport;

abstract class Vehicle {

	abstract void alertDriving();
}
