package story.transport;

public class TwoWheeler extends Vehicle implements Driving, Sleeping{

	public void alertDriving(Driving d, String name) { //override //object slicing
		System.out.println(name + " is ..");
		d.drive();
	}
		
		@Override
		public void drive() {
			// TODO Auto-generated method stub
			System.out.println("Driving without sleeping");
			
		}

		@Override
		public void sleep() {
			// TODO Auto-generated method stub
			System.out.println("Sleeping");
	}

		@Override
		void alertDriving() {
			// TODO Auto-generated method stub
			
		}
}

interface Driving {
	void drive();
}

interface Sleeping {
	void sleep();
}
