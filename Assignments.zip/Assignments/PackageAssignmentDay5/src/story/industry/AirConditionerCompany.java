package story.industry;

import story.people.Owner;

public class AirConditionerCompany extends Company {
	Company Id;
	public Owner ownerObj = new Owner(); //hasA //public
	int capital;
	RawMaterial rm;
	public static int totalNumberofACs; //static
	
	public void setOwner (String ownerName) {
		this.ownerObj.name = ownerName;
		System.out.println(this.ownerObj.name + " is owner of Air Conditioner Company");
	}
	
	//producesA					usesA
	public final AirConditioner manufactures(RawMaterial rm) //final
	{
		AirConditioner ac = new AirConditioner();
		System.out.println("Manufacturing Air Conditioner");
		totalNumberofACs++;
		return ac;
		
	}
	
	public Revenue saleofAirConditionesr() {
		Revenue r = new Revenue();
		System.out.println("Sale of Air Conditioners");
		return r;
	}
	
	public ReportCard getFeedback(AirConditioner ac)
	{
		ReportCard rc = new ReportCard();
		System.out.println("Report Card of Air Conditioner");
		return rc;
	}

}
