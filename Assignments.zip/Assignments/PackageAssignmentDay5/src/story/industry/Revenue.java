package story.industry;

public class Revenue {

}
