package story.industry;

public class AirConditioner {
	int acId;
}
