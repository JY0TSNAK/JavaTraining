package story.industry;

public class ReportCard extends FeedbackForm {

}
