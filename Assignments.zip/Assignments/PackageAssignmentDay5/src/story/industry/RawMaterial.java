package story.industry;

public class RawMaterial {

}
