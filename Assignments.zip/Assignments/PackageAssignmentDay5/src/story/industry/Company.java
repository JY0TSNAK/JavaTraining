package story.industry;

class Company {

}
