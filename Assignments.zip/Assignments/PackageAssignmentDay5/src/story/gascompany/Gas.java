package story.gascompany;

class Gas {
	GasBill useGas() {
		GasBill gb = new GasBill();
		return gb;
	}
}
