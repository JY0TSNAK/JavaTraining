package story.gascompany;

class GasBill {
	int gasBillId;
	void payGasBill(int gasBillId) {
		System.out.println("Paying Gas Bill");
	}
}
