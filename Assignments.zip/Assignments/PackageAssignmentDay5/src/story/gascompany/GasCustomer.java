package story.gascompany;

import story.people.Customer;

class GasCustomer extends Customer {
	int gasConnectionId;
}
