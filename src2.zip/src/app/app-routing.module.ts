import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { PersonalBankingComponent } from './personal-banking/personal-banking.component';
import { SuccessComponent } from './success/success.component';
import { TestRegisterComponent } from './test-register/test-register.component';
import { UnsuccessComponent } from './unsuccess/unsuccess.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'registration',
  children:[{path:'',component:TestRegisterComponent},
  {path:'success',component:SuccessComponent},
  {path:'unsuccess',component:UnsuccessComponent}]},
  {path:'success',component:SuccessComponent},
  {path:'unsuccess',component:UnsuccessComponent},
  {path:'contactus',component:ContactusComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'personalbanking',component:PersonalBankingComponent},
  {path:'home',component:HomeComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
