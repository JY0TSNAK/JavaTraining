import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menubaar',
  templateUrl: './menubaar.component.html',
  styleUrls: ['./menubaar.component.css']
})
export class MenubaarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
