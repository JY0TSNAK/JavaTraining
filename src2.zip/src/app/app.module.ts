import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MainbodyComponent } from './mainbody/mainbody.component';
import { TestbodyComponent } from './testbody/testbody.component';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TestRegisterComponent } from './test-register/test-register.component';
import { SuccessComponent } from './success/success.component';
import { MenubaarComponent } from './menubaar/menubaar.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { PersonalBankingComponent } from './personal-banking/personal-banking.component';
import { UnsuccessComponent } from './unsuccess/unsuccess.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainbodyComponent,
    TestbodyComponent,
    TestRegisterComponent,
    SuccessComponent,
    MenubaarComponent,
    ContactusComponent,
    AboutusComponent,
    HomeComponent,
    PersonalBankingComponent,
    UnsuccessComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
