import { TestBed } from '@angular/core/testing';

import { PostalDetailsService } from './postal-details.service';

describe('PostalDetailsService', () => {
  let service: PostalDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PostalDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
