import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { PostalDetailsService } from '../postal-details.service';
import { PostOffice } from './PostOffice';
import { ResponseDetails } from './ResponseDetails';

@Component({
  selector: 'app-testbody',
  templateUrl: './testbody.component.html',
  styleUrls: ['./testbody.component.css']
})
export class TestbodyComponent implements OnInit {

  tempPincode: string = "";
  responseDet: ResponseDetails = new ResponseDetails();
  selCity: string = "";
  selState: string = "";

  constructor(private pds: PostalDetailsService) {

  }

  ngOnInit() {
  }

  showPostalDetails() {
    this.pds.fetchPostalDetailsService(this.tempPincode).subscribe(
      (data: ResponseDetails) => {
        this.responseDet = data;
        console.log(this.responseDet);
      },
      (err) => {
        console.log(err);
      }
    );
  }

}


