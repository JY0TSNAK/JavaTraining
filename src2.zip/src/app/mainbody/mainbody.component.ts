import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-mainbody',
  templateUrl: './mainbody.component.html',
  styleUrls: ['./mainbody.component.css']
})
export class MainbodyComponent implements OnInit {

  

  constructor() { }

  ngOnInit(): void {
  }

  

}
