import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer2.AccountType;
import com.sbi.layer2.Address;
import com.sbi.layer3.ApplicantRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:myspring.xml")
public class ApplicantRepoTesting {
	
	@Autowired
	ApplicantRepository applRepo;
	
	@Test
	public void createApplicantTest() {
		
		Applicant applObj = new Applicant();
			
		applObj.setAccountType(AccountType.SAVINGS);
		applObj.setApplicantName("Jack Sparrow");
		applObj.setApplicantFatherName("Ben");
		applObj.setApplicantBirthDate(LocalDate.of(2000, 6, 15));
		applObj.setMarried("Married");
		applObj.setMobileNumber("9200024412");
		
		Address permanentAddr = new Address();
		Address correspondanceAddr = new Address();
		
		permanentAddr.setAddressType("Permanent");
		permanentAddr.setArea("15, Happy Home");
		permanentAddr.setStreet("West Avenue");
		permanentAddr.setCity("Mumbai");
		permanentAddr.setState("Maharastra");
		permanentAddr.setCountry("India");
		permanentAddr.setPincode(401501);
		permanentAddr.setApplicant(applObj);
		
		correspondanceAddr.setAddressType("correspondance");
		correspondanceAddr.setArea("ICL Towers, 2nd Floor");
		correspondanceAddr.setStreet("East Avenue");
		correspondanceAddr.setCity("Chennai");
		correspondanceAddr.setState("Tamilnadu");
		correspondanceAddr.setCountry("India");
		correspondanceAddr.setPincode(501901);
		correspondanceAddr.setApplicant(applObj);
		
		List<Address> addrList = new ArrayList<Address>();
		addrList.add(permanentAddr);
		addrList.add(correspondanceAddr);
		applObj.setAddressList(addrList);

		applObj.setAdhaarNumber("456712347890");
		applObj.setAnnualIncome(50000);
		applObj.setOccupation("Salaried");
		applObj.setPanCard("PKPF4120M");
		applObj.setPhoto("Jack.jpg");
		
		applObj.setApplicationStatus(ApplicationStatus.APPLIED);
			
		applRepo.createApplication(applObj);
	}

}
