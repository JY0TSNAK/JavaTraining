export class Register{
    applicantId: number=0;
    salutation: string="";
    applicantName: string="";
    applicantFatherName: string="";
    applicantBirthDate: Date=new Date();
    applicantGender: string="";
    emailId: string="";
    mobileNumber: number=0;
    applicantAadhar:number = 0;
    applicantPan: string ="";
    applicantOccupation: string="";
    applicantAnnualIncome: number=0; 
    applicationStatus: string="";   
    married: string="";
    address : string="";   
    
}