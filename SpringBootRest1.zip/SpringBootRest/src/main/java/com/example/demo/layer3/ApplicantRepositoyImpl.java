package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Applicant;
@Repository
public class ApplicantRepositoyImpl extends BaseRepositoryImpl implements ApplicantRepository

{

	@Transactional
	public void createApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		super.persist(applicant);
	}

	@Transactional
	public void modifyApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		super.merge(applicant);
	}

	@Transactional
	public void removeApplicant(int applicantId) {
		// TODO Auto-generated method stub
		Applicant appObj =super.find(Applicant.class, applicantId);
		super.remove(appObj);
	}

	@Override
	public Applicant findApplication(int applicantId) {
		// TODO Auto-generated method stub
		return super.find(Applicant.class, applicantId);
	}

	@Override
	public List<Applicant> findAllApplicants() {
		// TODO Auto-generated method stub
		return super.findAll("Applicant",Applicant.class);
	}

}

