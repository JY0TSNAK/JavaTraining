package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.ApplicantNew;

@Repository
public class ApplicantNewRepositoryImpl extends BaseRepositoryImpl implements ApplicantNewRepository {

	@Transactional
	public void createApplication(ApplicantNew applicant) {
		super.persist(applicant);
	}

	@Transactional
	public void modifyApplication(ApplicantNew applicant) {
		super.merge(applicant);

	}

	@Transactional
	public void removeApplication(int applicantId) {
		ApplicantNew appObj = super.find(ApplicantNew.class, applicantId);
		super.remove(appObj);
	}

	@Override
	public ApplicantNew findApplication(int applicantId) {
		return super.find(ApplicantNew.class, applicantId);
	}

	@Override
	public List<ApplicantNew> findAllApplicants() {
		//return super.findAll("Applicant");
		return super.findAll("ApplicantNew", ApplicantNew.class);
	}

	

}