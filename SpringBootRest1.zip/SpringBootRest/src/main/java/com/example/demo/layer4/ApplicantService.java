package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Applicant;

@Service
public interface ApplicantService {
 String createApplicationService(Applicant app);
	List<Applicant> getAllApplicants();
	void removeApplicant(int applicantId );
	void modifyApplicant(Applicant applicant);
	Applicant findApplicant(int applicantId);
	

}
