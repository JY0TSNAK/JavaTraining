package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.ApplicantNew;

@Repository
public interface ApplicantNewRepository {
	void createApplication(ApplicantNew applicant);
	void modifyApplication(ApplicantNew account);
	void removeApplication(int applicantId);
	ApplicantNew findApplication(int applicantId);
	List<ApplicantNew> findAllApplicants();
}
