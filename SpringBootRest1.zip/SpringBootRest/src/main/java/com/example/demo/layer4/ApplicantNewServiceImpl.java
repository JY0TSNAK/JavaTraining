package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.ApplicantNew;
import com.example.demo.layer3.ApplicantNewRepository;


@Service
public class ApplicantNewServiceImpl implements ApplicantNewService {

	@Autowired
	ApplicantNewRepository appRepo;
	
	@Override
	public void createApplicationService(ApplicantNew app) {
		
		appRepo.createApplication(app);
		System.out.println("ApplicantServiceImpl() : created the applicants data.....");

	}
	
	@Override
	public List<ApplicantNew> getAllApplicantsService() {
		return appRepo.findAllApplicants();
	}

	@Override
	public void modifyApplicationService(ApplicantNew applicant) {
		appRepo.modifyApplication(applicant);
	}

	@Override
	public void removeApplicationService(int applicantId) {
		appRepo.removeApplication(applicantId);
	}

	@Override
	public ApplicantNew findApplicationService(int applicantId) {
		return appRepo.findApplication(applicantId);
	}

}
