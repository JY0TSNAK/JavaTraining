package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.ApplicantNew;
import com.example.demo.layer4.ApplicantNewService;

@RestController
@RequestMapping("/newapplicants")
public class ApplicantNewController {
	
	
	@Autowired
	ApplicantNewService applicantService;
	
	public ApplicantNewController() {
		System.out.println("ApplicantController() constructor...");
	}
	
	@RequestMapping("/getNewApplicants") 
	public List<ApplicantNew> getAllApplicants() {
		System.out.println("/getApplicants");
		return applicantService.getAllApplicantsService();
	}
	
	@RequestMapping("/getNewApplicant/{applno}") 
	public ApplicantNew getAnApplicant(@PathVariable("applno") int applicantNumToSearch) {
		System.out.println("/getNewApplicant");
		
		ApplicantNew applicantObject = applicantService.findApplicationService(applicantNumToSearch);
		
		if (applicantObject != null) {
			return applicantObject;
		}
		else {
			throw new RuntimeException("Applicant Not Found");
		}
	}
	
	@RequestMapping("/deleteNewApplicant/{applno}") 
	public String deleteAnApplicant(@PathVariable("applno") int applicantNumToRemove) {
		System.out.println("/deleteNewApplicant");
		
		ApplicantNew applicantObject = applicantService.findApplicationService(applicantNumToRemove);
		
		if (applicantObject != null) {
			applicantService.removeApplicationService(applicantNumToRemove);
			return "Application deleted sucessfully : " + applicantNumToRemove;
		}
		else {
			return "Applicant Not Found";
		}
	}
	
	@RequestMapping("/updateNewApplicant") 
	public String updateAnApplicant(@RequestBody ApplicantNew applicantObjectToModify) {
		System.out.println("/updateNewApplicant");
		
		ApplicantNew applicantObject = applicantService.findApplicationService(applicantObjectToModify.getApplicantId());
		
		if (applicantObject != null) {
			applicantService.modifyApplicationService(applicantObject);
			return "Application updated sucessfully : " + applicantObjectToModify.getApplicantId();
		}
		else {
			return "Applicant Not Found";
		}
	}
	
	@RequestMapping("/addNewApplicant") 
	public String addAnApplicant(@RequestBody ApplicantNew applicantObjectToAdd) {
		System.out.println("/addNewApplicant");
		
		ApplicantNew applicantObject = applicantService.findApplicationService(applicantObjectToAdd.getApplicantId());
		
		if (applicantObject != null) {
			return "Applicant already exists Found";
		}
		else {
			applicantService.createApplicationService(applicantObject);
			return "Application created sucessfully : " + applicantObjectToAdd.getApplicantId();
		}
	}
	
	
}
