package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.AccountType;
import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.ApplicantRepository;

@SpringBootTest
class SpringBootRestApplicationTests {

	@Autowired
	ApplicantRepository applRepo;
	
	@Test
	void contextLoads() {
	}

	@Test
	void addApplicantTest() {
		Applicant applObj = new Applicant();
		
		applObj.setAccountType(AccountType.SAVINGS);
		applObj.setApplicantName("June Carter");
		applObj.setApplicantFatherName("Barry");
		applObj.setApplicantBirthDate(LocalDate.of(2001, 5, 20));
		applObj.setMarried("UnMarried");
		applObj.setMobileNumber("9845612365");
		
		Address permanentAddr = new Address();
		Address correspondanceAddr = new Address();
		
		permanentAddr.setAddresstype("Permanent");
		permanentAddr.setArea("87, Swan Towers");
		permanentAddr.setStreet("West Avenue");
		permanentAddr.setCity("Kolkata");
		permanentAddr.setState("West Bengal");
		permanentAddr.setCountry("India");
		permanentAddr.setPincode(701521);
		permanentAddr.setApplicant(applObj); //set applicant to address
		
		correspondanceAddr.setAddresstype("correspondance");
		correspondanceAddr.setArea("FGR Towers, 3rd Floor");
		correspondanceAddr.setStreet("East Avenue");
		correspondanceAddr.setCity("Hyderabad");
		correspondanceAddr.setState("Telangana");
		correspondanceAddr.setCountry("India");
		correspondanceAddr.setPincode(500721);
		correspondanceAddr.setApplicant(applObj); //set applicant to address
		
		List<Address> addrList = new ArrayList<Address>();
		addrList.add(permanentAddr); //add address to address list
		addrList.add(correspondanceAddr); //add address to address list
		applObj.setAddressList(addrList); //set address list to applicant

		applObj.setAdhaarNumber("123545688745");
		applObj.setAnnualIncome(45000);
		applObj.setOccupation("Professional");
		applObj.setPanCard("IJHYP4512F");
		applObj.setPhoto("June.jpg");
		
		applObj.setApplicationStatus(ApplicationStatus.APPLIED);
			
		applRepo.createApplication(applObj);
		
	}
	
	@Test
	void loadAllApplicantsTest() {
		List<Applicant> allApplicants = applRepo.findAllApplicants();
		
		for(Applicant applicant : allApplicants) {
			System.out.println("Applicant Id : " + applicant.getApplicantId());
			System.out.println("Applicant Name : " + applicant.getApplicantName());
			System.out.println("Applicant Father Name : " + applicant.getApplicantFatherName());
			System.out.println("Applicant Birth Date : " + applicant.getApplicantBirthDate());
			System.out.println("Applicant Mobile Number : " + applicant.getMobileNumber());
			System.out.println("Applicant Married : " + applicant.getMarried());
			System.out.println("Applicant Occupation : " + applicant.getOccupation());
			System.out.println("Applicant Aadhar : " + applicant.getAdhaarNumber());
			System.out.println("Applicant PAN : " + applicant.getPanCard());
			System.out.println("Applicant Photo : " + applicant.getPhoto());
			System.out.println("Applicant Annual Income : " + applicant.getAnnualIncome());
			System.out.println("Applicant Status : " + applicant.getApplicationStatus());
			
			List<Address> addressList = applicant.getAddressList();
			for(Address address : addressList) {
				System.out.println("------------------------------------------");
				System.out.println("Address Id : " + address.getAddressid());
				System.out.println("Address type : " + address.getAddresstype());
				System.out.println("Address area : " + address.getArea());
				System.out.println("Address Street : " + address.getStreet());
				System.out.println("Address City : " + address.getCity());
				System.out.println("Address State : " + address.getState());
				System.out.println("Address Country : " + address.getCountry());
				System.out.println("Address Pincode : " + address.getPincode());
			}
			System.out.println("=================================================");
		}
	}
	
	@Test
	void loadApplicantByIdTest() {
		Applicant applicant = applRepo.findApplication(50);
		Assertions.assertTrue(applicant!=null);
		
		
			System.out.println("Applicant Id : " + applicant.getApplicantId());
			System.out.println("Applicant Name : " + applicant.getApplicantName());
			System.out.println("Applicant Father Name : " + applicant.getApplicantFatherName());
			System.out.println("Applicant Birth Date : " + applicant.getApplicantBirthDate());
			System.out.println("Applicant Mobile Number : " + applicant.getMobileNumber());
			System.out.println("Applicant Married : " + applicant.getMarried());
			System.out.println("Applicant Occupation : " + applicant.getOccupation());
			System.out.println("Applicant Aadhar : " + applicant.getAdhaarNumber());
			System.out.println("Applicant PAN : " + applicant.getPanCard());
			System.out.println("Applicant Photo : " + applicant.getPhoto());
			System.out.println("Applicant Annual Income : " + applicant.getAnnualIncome());
			System.out.println("Applicant Status : " + applicant.getApplicationStatus());
			
			List<Address> addressList = applicant.getAddressList();
			Assertions.assertTrue(addressList.size()>0);
			for(Address address : addressList) {
				System.out.println("------------------------------------------");
				System.out.println("Address Id : " + address.getAddressid());
				System.out.println("Address type : " + address.getAddresstype());
				System.out.println("Address area : " + address.getArea());
				System.out.println("Address Street : " + address.getStreet());
				System.out.println("Address City : " + address.getCity());
				System.out.println("Address State : " + address.getState());
				System.out.println("Address Country : " + address.getCountry());
				System.out.println("Address Pincode : " + address.getPincode());	
			}
		}
	
	@Test
	void modifyApplicantTest() {
		Applicant applicant = applRepo.findApplication(44);
		Assertions.assertTrue(applicant!=null);
		
			System.out.println("Current Applicant Details");
			System.out.println("Applicant Id : " + applicant.getApplicantId());
			System.out.println("Applicant Name : " + applicant.getApplicantName());
			System.out.println("Applicant Father Name : " + applicant.getApplicantFatherName());
			System.out.println("Applicant Birth Date : " + applicant.getApplicantBirthDate());
			System.out.println("Applicant Mobile Number : " + applicant.getMobileNumber());
			System.out.println("Applicant Married : " + applicant.getMarried());
			System.out.println("Applicant Occupation : " + applicant.getOccupation());
			System.out.println("Applicant Aadhar : " + applicant.getAdhaarNumber());
			System.out.println("Applicant PAN : " + applicant.getPanCard());
			System.out.println("Applicant Photo : " + applicant.getPhoto());
			System.out.println("Applicant Annual Income : " + applicant.getAnnualIncome());
			System.out.println("Applicant Status : " + applicant.getApplicationStatus());
			
			System.out.println("Current Address List");
			List<Address> addressList = applicant.getAddressList();
			Assertions.assertTrue(addressList.size()>0);
			for(Address address : addressList) {
				System.out.println("------------------------------------------");
				System.out.println("Address Id : " + address.getAddressid());
				System.out.println("Address type : " + address.getAddresstype());
				System.out.println("Address area : " + address.getArea());
				System.out.println("Address Street : " + address.getStreet());
				System.out.println("Address City : " + address.getCity());
				System.out.println("Address State : " + address.getState());
				System.out.println("Address Country : " + address.getCountry());
				System.out.println("Address Pincode : " + address.getPincode());	
			}
			
			applicant.setApplicationStatus(ApplicationStatus.IN_PROGRESS);
			applicant.setAnnualIncome(65000);
			applicant.setOccupation("Business");
			
			applRepo.modifyApplication(applicant);
		}
	
	@Test
	void deleteApplicantTest() {
		applRepo.removeApplication(50);
	}
	
	@Test
	void changeMobileNumberTest() {
		Applicant applicant = applRepo.findApplication(68);
		applicant.setMobileNumber("9853145662");
		applRepo.modifyApplication(applicant);
	}

}
