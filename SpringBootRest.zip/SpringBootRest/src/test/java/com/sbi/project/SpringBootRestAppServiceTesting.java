package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.AccountType;
import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer4.ApplicantService;

@SpringBootTest
public class SpringBootRestAppServiceTesting {

	@Autowired
	ApplicantService applService;

	@Test
	void loadAllApplicantServiceTest() {
		List<Applicant> allApplicants = applService.getAllApplicantsService();

		for (Applicant applicant : allApplicants) {
			System.out.println("Applicant Id : " + applicant.getApplicantId());
			System.out.println("Applicant Name : " + applicant.getApplicantName());
			System.out.println("Applicant Father Name : " + applicant.getApplicantFatherName());
			System.out.println("Applicant Birth Date : " + applicant.getApplicantBirthDate());
			System.out.println("Applicant Mobile Number : " + applicant.getMobileNumber());
			System.out.println("Applicant Married : " + applicant.getMarried());
			System.out.println("Applicant Occupation : " + applicant.getOccupation());
			System.out.println("Applicant Aadhar : " + applicant.getAdhaarNumber());
			System.out.println("Applicant PAN : " + applicant.getPanCard());
			System.out.println("Applicant Photo : " + applicant.getPhoto());
			System.out.println("Applicant Annual Income : " + applicant.getAnnualIncome());
			System.out.println("Applicant Status : " + applicant.getApplicationStatus());

			List<Address> addressList = applicant.getAddressList();
			for (Address address : addressList) {
				System.out.println("------------------------------------------");
				System.out.println("Address Id : " + address.getAddressid());
				System.out.println("Address type : " + address.getAddresstype());
				System.out.println("Address area : " + address.getArea());
				System.out.println("Address Street : " + address.getStreet());
				System.out.println("Address City : " + address.getCity());
				System.out.println("Address State : " + address.getState());
				System.out.println("Address Country : " + address.getCountry());
				System.out.println("Address Pincode : " + address.getPincode());
			}
			System.out.println("=================================================");
		}
	}

	@Test
	void addApplicantServiceTest() {
		Applicant applObj = new Applicant();

		applObj.setAccountType(AccountType.SAVINGS);
		applObj.setApplicantName("Tom Miller");
		applObj.setApplicantFatherName("Baron");
		applObj.setApplicantBirthDate(LocalDate.of(1999, 6, 10));
		applObj.setMarried("UnMarried");
		applObj.setMobileNumber("9512375321");

		Address permanentAddr = new Address();
		Address correspondanceAddr = new Address();

		permanentAddr.setAddresstype("Permanent");
		permanentAddr.setArea("87, Swan Towers");
		permanentAddr.setStreet("New Avenue");
		permanentAddr.setCity("Chennai");
		permanentAddr.setState("Tamilnadu");
		permanentAddr.setCountry("India");
		permanentAddr.setPincode(601236);
		//permanentAddr.setApplicant(applObj); // set applicant to address

		correspondanceAddr.setAddresstype("correspondance");
		correspondanceAddr.setArea("FGR Towers, 3rd Floor");
		correspondanceAddr.setStreet("East Avenue");
		correspondanceAddr.setCity("Bangalore");
		correspondanceAddr.setState("Karnataka");
		correspondanceAddr.setCountry("India");
		correspondanceAddr.setPincode(721536);
		//correspondanceAddr.setApplicant(applObj); // set applicant to address

		List<Address> addrList = new ArrayList<Address>();
		addrList.add(permanentAddr); // add address to address list
		addrList.add(correspondanceAddr); // add address to address list
		applObj.setAddressList(addrList); // set address list to applicant

		applObj.setAdhaarNumber("654714523256");
		applObj.setAnnualIncome(45000);
		applObj.setOccupation("Business");
		applObj.setPanCard("PKJUP2584M");
		applObj.setPhoto("Tom.jpg");

		applObj.setApplicationStatus(ApplicationStatus.APPLIED);

		applService.createApplicationService(applObj);
	}
	
	@Test
	void changeMobileNumberServiceTest() {
		Applicant applicant = applService.findApplicationService(68);
		applicant.setMobileNumber("9853145663");
		applService.modifyApplicationService(applicant);
	}

}
