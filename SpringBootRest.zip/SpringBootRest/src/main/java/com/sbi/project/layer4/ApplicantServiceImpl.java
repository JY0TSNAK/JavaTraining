package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;

@Service
public class ApplicantServiceImpl implements ApplicantService {
	
	@Autowired
	ApplicantRepository applRepo;

	@Override
	public void createApplicationService(Applicant applicant) {
		List<Address> addressList = applicant.getAddressList();
		for(Address address : addressList) {
			address.setApplicant(applicant);
		}
				
		applRepo.createApplication(applicant);
		System.out.println("ApplicantServiceImpl () called");
		
	}

	@Override
	public List<Applicant> getAllApplicantsService() {
		
		return applRepo.findAllApplicants();
		
	}

	@Override
	public void modifyApplicationService(Applicant applicant) {
		applRepo.modifyApplication(applicant);
		
	}

	@Override
	public void removeApplicationService(int applicantId) {
		applRepo.removeApplication(applicantId);
		
	}

	@Override
	public Applicant findApplicationService(int applicantId) {
		return applRepo.findApplication(applicantId);
	}

}
