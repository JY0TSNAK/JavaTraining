package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@CrossOrigin
@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	@Autowired
	ApplicantService applService;
		
	public ApplicantController() {
		System.out.println("ApplicantController() called..");
	}
	
	@RequestMapping("/getApplicants") // http://localhost:8080/applicants/getApplicants
	public List<Applicant> getAllApplicants() {
		System.out.println("/getApplicants..");
		return applService.getAllApplicantsService();
	}

	@RequestMapping("/getApplicant/{applno}") 
	public Applicant getAnApplicant(@PathVariable("applno") int applicantNumToSearch) {
		System.out.println("/getApplicant");
		
		Applicant applicantObject = applService.findApplicationService(applicantNumToSearch);
		
		if (applicantObject != null) {
			return applicantObject;
		}
		else {
			throw new RuntimeException("Applicant Not Found");
		}
	}
	
	@RequestMapping("/deleteApplicant/{applno}") 
	public String deleteAnApplicant(@PathVariable("applno") int applicantNumToRemove) {
		System.out.println("/deleteApplicant");
		
		Applicant applicantObject = applService.findApplicationService(applicantNumToRemove);
		
		if (applicantObject != null) {
			applService.removeApplicationService(applicantNumToRemove);
			return "Application deleted sucessfully : " + applicantNumToRemove;
		}
		else {
			return "Applicant Not Found";
		}
	}
	
	@PutMapping("/updateAnApplicant") 
	public String updateAnApplicant(@RequestBody Applicant applicantObjectToModify) {
		applService.modifyApplicationService(applicantObjectToModify);
		return "Application updated sucessfully";
//		System.out.println("/updateAnApplicant");
//		Applicant applicantObject = applService.findApplicationService(applicantObjectToModify.getApplicantId());
//		
//		if (applicantObject != null) {
//			applService.modifyApplicationService(applicantObjectToModify);
//			return "Application updated sucessfully : " + applicantObjectToModify.getApplicantId();
//		}
//		else {
//			return "Applicant Not Found";
//		}
	}
	
	@PostMapping("/addAnApplicant") 
	public String addAnApplicant(@RequestBody Applicant applicantObjectToAdd) {
		applService.createApplicationService(applicantObjectToAdd);
		return "Application created sucessfully";
		
//		System.out.println("/addAnApplicant");
//		
//		Applicant applicantObject = applService.findApplicationService(applicantObjectToAdd.getApplicantId());
//		
//		if (applicantObject != null) {
//			return "Applicant already exists Found";
//		}
//		else {
//			applService.createApplicationService(applicantObjectToAdd);
//			//return "Application created sucessfully : " + applicantObjectToAdd.getApplicantId();
//			return "Application created sucessfully";
//		}
	}

}
