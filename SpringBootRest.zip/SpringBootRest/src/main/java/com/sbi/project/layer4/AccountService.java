package com.sbi.project.layer4;

import org.springframework.stereotype.Service;

@Service
public interface AccountService {

	void openBankAccountService(int applicantId);
	
}
