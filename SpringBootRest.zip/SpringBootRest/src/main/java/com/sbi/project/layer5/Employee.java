package com.sbi.project.layer5;
import java.time.LocalDate;

public class Employee {
	

	private int employeeNumber; 
	private String name;
	private String job;
	private LocalDate joiningDate;
	private double salary;
	private int age;
	
	public Employee() {
		super();
		System.out.println("Employee Created..");
	}

	public Employee(int employeeNumber, String name, String job, LocalDate joiningDate, double salary, int age) {
		super();
		this.employeeNumber = employeeNumber;
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
	}



	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public LocalDate getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", name=" + name + ", job=" + job + ", joiningDate="
				+ joiningDate + ", salary=" + salary + ", age=" + age + "]";
	}


	
	
}
