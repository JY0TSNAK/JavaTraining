package com.sbi.project.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.ApplicantRepository;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	ApplicantRepository applRepo;
	
	@Autowired
	AccountRepository accRepo;
	
	public void openBankAccountService(int applicantId) {
		
		
		Applicant applicant = applRepo.findApplication(applicantId);
		
		if (applicant != null) {
			Account account = new Account();
			account.setAccountHolderName(applicant.getApplicantName());
			account.setAccountBalance(5000);
			account.setApplicant(applicant);

			applicant.setApplicationStatus(ApplicationStatus.APPROVED);

			applRepo.modifyApplication(applicant);
			accRepo.createAccount(account);
		} else {
			throw new RuntimeException("Application Id not found : "+applicantId);
		}
	}

}
