package com.sbi.project.layer5;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetings")
public class GreetingController {

	@RequestMapping("/greet") // http://localhost:8080/greetings/greet
	public String greetingMessage() {
		return "Welcome to Spring Web Rest based application";
	}
	
	@RequestMapping("/boot") // http://localhost:8080/greetings/boot
	public String welcomeMessage() {
		return "Welcome to Spring Boot apps";
	}
	
	@RequestMapping("/web") // http://localhost:8080/greetings/web
	public String regardsMessage() {
		return "<h1>Welcome to Spring Web Apps</h1>";
	}
	
	@RequestMapping("/emp") // http://localhost:8080/greetings/emp
	public String displayEmp() {
		
		Employee emp = new Employee();
		//return "Employee Details: Employee ID: " + emp.getEmpId() + ", Employee Name : " + emp.getEmpName() + ", Employee Department : " + emp.getEmpdept();
		return "Employee Details : " + emp;
		
	}
}

