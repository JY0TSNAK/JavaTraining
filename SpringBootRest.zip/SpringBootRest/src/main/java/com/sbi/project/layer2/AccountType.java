package com.sbi.project.layer2;

public interface AccountType {

	String  SAVINGS="Savings";
	String  CURRENT="Cuurent";
	String  FIXED="Fixed Deposit";
	String  RECURRING="Recurring Deposit";
	
}
