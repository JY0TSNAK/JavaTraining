package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BaseRepositoryImpl implements BaseRepository {
	
	//@PersistenceContext(unitName="MyJPA")
	@PersistenceContext
	EntityManager entityManager;
	
	public BaseRepositoryImpl() {
		System.out.println("BaseDAOImpl()..");
	}
	
	public void persist(Object obj) { //user defined fun
		entityManager.persist(obj);
	}
	
	public void merge(Object obj) { //user defined fun
		entityManager.merge(obj);
	}
	
	public void remove(Object obj) { //user defined fun
		entityManager.remove(obj);
	}
	
	public <AnyType> AnyType find(Class<AnyType> className, Serializable primaryKey) { //user defined fun //E any type of class
		AnyType e = entityManager.find(className, primaryKey);
		return e;
	}
	
	public <AnyType> List<AnyType> findAll(String entityName, Class<AnyType> className) { //user defined fun //E any type of class
		//Query query = entityManager.createQuery("from " + entityName);
		//return query.getResultList();
		
		TypedQuery<AnyType> typedQuery = entityManager.createQuery("from "+ entityName, className);
		return typedQuery.getResultList();
	}
}
