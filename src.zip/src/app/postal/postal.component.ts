import { Component, OnInit } from '@angular/core';
import { PostalService } from '../postal.service';
import { ResponseDetails } from './ResponseDetails';

@Component({
  selector: 'app-postal',
  templateUrl: './postal.component.html',
  styleUrls: ['./postal.component.css']
})
export class PostalComponent implements OnInit {

  tempPincode: string = "";
  responseDet: ResponseDetails = new ResponseDetails();
  selCity: string = "";
  selState: string = "";

  constructor(private ps: PostalService) { }

  ngOnInit(): void {
  }

  showPostalDetails() {
    this.ps.fetchPostalDetailsService(this.tempPincode).subscribe(
      (data: ResponseDetails)=>
      {
        this.responseDet=data;
        console.log(this.responseDet);
      },
      (err)=>
      {
        console.log(err);
      }
    )
  }

}
