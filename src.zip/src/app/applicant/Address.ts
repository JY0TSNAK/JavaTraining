export class Address {
    addressid: number = 0;
    addresstype: string = "";
    area: string = "";
    street: string = "";
    city: string = "";
    state: string = "";
    country: string = "";
    pincode: number = 0;
}