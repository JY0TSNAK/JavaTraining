import { Address } from "./Address";

export class Applicant {
    applicantId: number = 0;
    accountType: string = "";
    applicantName: string = "";
    applicantFatherName: string = "";
    applicantBirthDate: Date = new Date();
    mobileNumber: string = "";
    married: string = "";
    occupation: string = "";
    addressList: Address[] = [];
    adhaarNumber: string = "";
    panCard: string = "";
    photo: string = "";
    annualIncome: number = 0.00;
    applicationStatus: string = "";
}