import { Component, OnInit } from '@angular/core';
import { ApplicantService } from '../applicant.service';
import { Applicant } from './Applicant';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {

  applicantArray: Applicant[] = [];
  msg: any = "";
  
  constructor(private applServ: ApplicantService) { }

  ngOnInit(): void {
    this.showAllApplicants();
  }

  showAllApplicants() {
    console.log('showAllApplicants() invoking loadAllApplicantsService()..');
    this.applServ.loadAllApplicantsService().subscribe(
      (data: Applicant[])=>
      {
        this.applicantArray = data;
      },
      (err) =>
      {
        console.log(err);
      }
    );
  }

  updateApplicat(modifiedApplicant: Applicant){
    console.log('updateApplicat() invoking updateApplicantService()..');
    this.applServ.updateApplicantService(modifiedApplicant).subscribe(
      (data:any)=>
      {
        this.msg = data;
        console.log(this.msg);
      },
      (err)=>
      {
        console.log(err);
      }
    )
  }
}
