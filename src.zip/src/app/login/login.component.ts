import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName: string="";
  pwd: string="";

  constructor() { }

  ngOnInit(): void {
  }

  authenticateUser() {
    if(this.userName == "Admin" && this.pwd=="admin") {
        
    }
  }

}
