import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest',
  templateUrl: './simple-interest.component.html',
  styleUrls: ['./simple-interest.component.css']
})
export class SimpleInterestComponent implements OnInit {

  principal: number = 5000; //data member
  period: number = 10;
  rate:number = 4.5;
  si:number = 0;

  lnPrincipal: number = 500000;
  lnTenure: number = 20;
  lnROI: number = 6.5;
  emi: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

  calculateSI() { //member function
    console.log ('calculateSI is invoked..');
    this.si = (this.principal * this.period * this.rate)/100;
  }

  calculateEMI() { //member function
    console.log ('calculateEMI is invoked..');
    this.emi = (this.lnPrincipal * (this.lnROI/1200))*(((1+this.lnROI/1200)^this.lnTenure)/(((1+this.lnROI/1200)^this.lnTenure)-1));
  }

}
