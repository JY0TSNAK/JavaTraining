import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {

  allCountries: string[] = ["GBP: British Pound Sterling", "EUR:Euro", "INR:Indian Rupee", "USD:US Dollar"];
  sourceCountry: string = "";
  targetCountry: string = "";
  amountToConvert: number = 0;
  convertedAmount: number = 0;

  constructor(private currConvServ: CurrencyConverterService) { }

  ngOnInit(): void {
  }

  convert() {
    this.convertedAmount = this.currConvServ.convertService(this.sourceCountry, this.targetCountry, this.amountToConvert);
  }

}
