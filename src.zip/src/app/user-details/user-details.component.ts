import { Component, OnInit } from '@angular/core';
import { UserDetailsServiceService } from '../user-details-service.service';
import { UserDetails } from './UserDetails';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  tempUserId : number = 1;
  userDetails : UserDetails = new UserDetails();
  userDetailsArray : UserDetails[] =[];

  constructor(private uds : UserDetailsServiceService) { }

  ngOnInit(): void {
  }

  showUserDetails() {
    this.uds.fetchUserDetailsService(this.tempUserId).subscribe(
      (data: UserDetails)=>
      {
        this.userDetails = data;
        console.log(data);
      },
      (err)=>
      {
        console.log(err);
      }
    );
  }

  showAllUsersDetails() {
    this.uds.fetchAllUsersDetailsService().subscribe(
      (data: UserDetails[])=>
      {
        this.userDetailsArray = data;
        console.log(data);
      },
      (err)=>
      {
        console.log(err);
      }
    );
  }

}
