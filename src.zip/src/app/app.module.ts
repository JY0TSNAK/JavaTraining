import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MainbodyComponent } from './mainbody/mainbody.component';
import { MenubarComponent } from './menubar/menubar.component';
import { SimpleInterestComponent } from './simple-interest/simple-interest.component';
import { FormsModule } from '@angular/forms';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { StatementModule } from './statement/statement.module';
import { CalculatorComponent } from './calculator/calculator.component';
import { CurrencyConvertorComponent } from './currency-convertor/currency-convertor.component';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';

import { HttpClientModule } from '@angular/common/http';
import { UserDetailsComponent } from './user-details/user-details.component';
import { ApplyComponent } from './apply/apply.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainbodyComponent,
    MenubarComponent,
    SimpleInterestComponent,
    AddPayeeComponent,
    ApplicantComponent,
    CalculatorComponent,
    CurrencyConvertorComponent,
    CurrencyConverterComponent,
    UserDetailsComponent,
    ApplyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    StatementModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
