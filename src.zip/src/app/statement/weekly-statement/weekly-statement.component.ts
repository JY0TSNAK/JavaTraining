import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weekly-statement',
  templateUrl: './weekly-statement.component.html',
  styleUrls: ['./weekly-statement.component.css']
})
export class WeeklyStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
