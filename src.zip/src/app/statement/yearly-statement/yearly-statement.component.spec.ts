import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyStatementComponent } from './yearly-statement.component';

describe('YearlyStatementComponent', () => {
  let component: YearlyStatementComponent;
  let fixture: ComponentFixture<YearlyStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YearlyStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
