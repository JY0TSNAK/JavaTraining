import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WeeklyStatementComponent } from './weekly-statement/weekly-statement.component';
import { MonthlyStatementComponent } from './monthly-statement/monthly-statement.component';
import { YearlyStatementComponent } from './yearly-statement/yearly-statement.component';



@NgModule({
  declarations: [
    WeeklyStatementComponent,
    MonthlyStatementComponent,
    YearlyStatementComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    WeeklyStatementComponent
  ]
})
export class StatementModule { }
