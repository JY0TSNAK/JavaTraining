import { Component, OnInit } from '@angular/core';
import { ApplicantService } from '../applicant.service';
import { Address } from '../applicant/Address';
import { Applicant } from '../applicant/Applicant';

@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {

  applicant: Applicant = new Applicant();
  permAddress:Address = new Address();
  corrAddress:Address = new Address();
  msg: any = "";

  constructor(private applServ: ApplicantService) { }

  ngOnInit(): void {
  }

  applyForBankAccount() {
    console.log('applyForBankAccount() invoking addApplicantService()..');
    this.permAddress.addresstype = "Permanent";
    this.corrAddress.addresstype = "Correspondance";
    this.applicant.applicationStatus = "Applied";
    this.applicant.addressList.push(this.permAddress);
    this.applicant.addressList.push(this.corrAddress);
    this.applServ.addApplicantService(this.applicant).subscribe(
      (data:any)=>
      {
        this.msg = data;
        console.log(this.msg);
      },
      (err)=>
      {
        console.log(err);
      }
    )
  }

}
