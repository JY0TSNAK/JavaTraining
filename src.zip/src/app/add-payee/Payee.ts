export class Payee {
    payeeId: number = 0;
    payeeAccountNumber: number = 0;
    payeeName: string = "";
    payeeIFSC: string = "";
    payeeNickName: string = "";
}