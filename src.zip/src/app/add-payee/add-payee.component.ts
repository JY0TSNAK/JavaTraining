import { Component, OnInit } from '@angular/core';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {

  tempPayeeAccountNumber: number = 0;
  payeeObj: Payee = new Payee();
  errMsg: string = "";

  payeeArray: Payee[] = [
    { payeeId:1, payeeAccountNumber:123123123, payeeName:"Jack Smith", payeeIFSC:"SBIN00012345", payeeNickName:"Jk" }, 
    { payeeId:2, payeeAccountNumber:456456456, payeeName:"Jill", payeeIFSC:"SBIN00067890", payeeNickName:"Jl" },
    { payeeId:3, payeeAccountNumber:789789789, payeeName:"Jane", payeeIFSC:"SBIN00014785", payeeNickName:"Jn" },
    { payeeId:4, payeeAccountNumber:147147147, payeeName:"Julie", payeeIFSC:"SBIN00065478", payeeNickName:"Ji" },
    { payeeId:5, payeeAccountNumber:369369369, payeeName:"June", payeeIFSC:"SBIN00078953", payeeNickName:"Ju" }
  ];

  tempPayeeArray1: Payee[]=this.payeeArray;
  tempPayeeArray2: Payee[]=this.payeeArray;

  constructor() { }

  ngOnInit(): void {
  }

  verifyAccountNumber() {
    if(this.payeeObj.payeeAccountNumber != this.tempPayeeAccountNumber) {
      this.errMsg="Payee Account Number does not match";
    }
    else {
      this.errMsg="";
    }
  }

  addPayee() {
    this.payeeObj.payeeId = this.payeeArray.length + 1;
    this.payeeArray.push(this.payeeObj);
  }

  deletePayee(payeeToBeDeleted: Payee) {
    
    this.payeeArray = this.payeeArray.filter(item=> item!== payeeToBeDeleted);
  
  }

  reloadPayees(payeeFound: Payee) {
    this.tempPayeeArray1 = this.tempPayeeArray2; //load original array
    this.tempPayeeArray1 = this.tempPayeeArray1.filter(item=> item.payeeName.match(payeeFound.payeeName));
    this.payeeArray = this.tempPayeeArray1;
  }

}
