import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  convertedAmount:number = 0;

  constructor() { }

  convertService(source:string, target:string, amountToConvert:number) : number {
    if(source == "USD:US Dollar" && target == "INR:Indian Rupee") {
      this.convertedAmount = amountToConvert*78;
    }
    else if(source == "INR:Indian Rupee" && target == "USD:US Dollar") {
      this.convertedAmount = amountToConvert/78;
    }
   
    return this.convertedAmount;
  }
}
