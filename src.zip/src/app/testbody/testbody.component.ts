import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testbody',
  templateUrl: './testbody.component.html',
  styleUrls: ['./testbody.component.css']
})
export class TestbodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
