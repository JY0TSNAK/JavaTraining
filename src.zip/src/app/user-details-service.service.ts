import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserDetails } from './user-details/UserDetails';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsServiceService {

  constructor(private myHttp : HttpClient) { }

  fetchUserDetailsService(userId :number) : Observable<UserDetails> {
      return this.myHttp.get<UserDetails>("https://jsonplaceholder.typicode.com/users/" + userId);
  }

  fetchAllUsersDetailsService() : Observable<UserDetails[]> {
    return this.myHttp.get<UserDetails[]>("https://jsonplaceholder.typicode.com/users/");
  }
    
  }

