package com.sbi.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_tbl")
public class Applicant {
	
	@Id @GeneratedValue @Column(name="applicant_id")
	private int applicantId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_fathername")
	private String applicantFatherName;
	
	@DateTimeFormat(pattern="yyyy/MM/dd")
	@Column(name="applicant_dob")
	private LocalDate applicantBirthDate;
	
	@Column(name="applicant_mobile")
	private String mobileNumber;
	
	@Column(name="applicant_married")
	private String married;
	
	@Column(name="applicant_occupation")
	private String occupation;
	
	@OneToMany (mappedBy="applicant", cascade = CascadeType.ALL)
	List<Address> addressList = new ArrayList<Address>();

	@Column(name="applicant_adhaar")
	private String adhaarNumber;
	
	@Column(name="applicant_pan")
	private String panCard;
	
	@Column(name="applicant_photo")
	private String photo;
	
	@Column(name="applicant_annual_income")
	private float annualIncome;
	
	@Column(name="application_status")
	private String applicationStatus;

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		System.out.println("getApplicantName() called");
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		System.out.println("setApplicantName() called");
		this.applicantName = applicantName;
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	public LocalDate getApplicantBirthDate() {
		return applicantBirthDate;
	}

	public void setApplicantBirthDate(String applicantBirthDate) {
		LocalDate date = LocalDate.parse(applicantBirthDate);
		this.applicantBirthDate = date;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public String getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(String adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public float getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(float annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	
}
