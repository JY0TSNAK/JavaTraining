package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;
import com.sbi.layer3.ApplicantRepository;
import com.sbi.layer3.ApplicantRepositoryImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService {
	
	//@Autowired
	ApplicantRepository applRepo = new ApplicantRepositoryImpl();

	@Override
	public void createApplicationSerice(Applicant appl) {
		// TODO Auto-generated method stub
		
		applRepo.createApplication(appl);
		System.out.println("ApplicantServiceImpl () called");

	}

}
