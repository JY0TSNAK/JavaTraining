package com.sbi.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository {
	
	//@PersistenceContext(unitName="MyJPA")
	
	EntityManager entityManager;
	
	public BaseRepositoryImpl() {
		System.out.println("BaseRepositoryImpl()..");
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		entityManager = entityManagerFactory.createEntityManager();
	}
	
	public void persist(Object obj) { //user defined fun
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		entityManager.persist(obj);
		tx.commit();
	}
	
	public void merge(Object obj) { //user defined fun
		entityManager.merge(obj);
	}
	
	public void remove(Object obj) { //user defined fun
		entityManager.remove(obj);
	}
	
	public <AnyType> AnyType find(Class<AnyType> className, Serializable primaryKey) { //user defined fun //E any type of class
		AnyType e = entityManager.find(className, primaryKey);
		return e;
	}
	
	public <AnyType> List<AnyType> findAll(String entityName) { //user defined fun //E any type of class
		Query query = entityManager.createQuery("from " + entityName);
		return query.getResultList();
	}
}
