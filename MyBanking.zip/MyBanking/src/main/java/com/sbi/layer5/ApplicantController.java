package com.sbi.layer5;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sbi.layer2.Applicant;

@Controller
//@RequestMapping("/applicant") 
public class ApplicantController {
	
	public ApplicantController() {
		System.out.println("ApplicantController() called");
	}

	@RequestMapping("/greet1") //controller
	public String greeting() {
		
		//logic here - model
		
		return "hello"; //hello.jsp view
	}
	
	@RequestMapping("/apply") //controller
	public String applyForNewBankAccount() {
		
		//logic here - model
		
		return "ApplyForBankAccount"; //ApplyForBankAccount.jsp view
	}
	
	@RequestMapping("/create") //controller
	public String createApplicationData(Applicant applObj) {
		
		//logic here - model
		
		return null; //ApplyForBankAccount.jsp view
	}
}
