package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GreetingServlet
 */
@WebServlet("/greet")
public class GreetingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GreetingServlet() {
        super();
        System.out.println("GreetingServlet() ctor..");
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() called..");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("destroy() called..");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LocalDateTime CurrentDateTime = LocalDateTime.now();
		int hod = CurrentDateTime.getHour();
		String GreetMsg = "";
		if(hod>=4 && hod <=12) {
			GreetMsg = "Good Morning";
		}
		else if(hod>=12 && hod <=13) {
			GreetMsg = "Good Noon";
		}
		else if(hod>=13 && hod <=16) {
			GreetMsg = "Good Afternoon";
		}
		else if(hod>=17 && hod <=20) {
			GreetMsg = "Good Evening";
		}
		else if(hod>=21 && hod <= 00) {
			GreetMsg = "Good Night";
		}
		else if(hod>=01 && hod <=03) {
			GreetMsg = "Good MidNight";
		}
		String yourName = request.getParameter("myname");
		PrintWriter pw = response.getWriter();
		String clientAddress = request.getRemoteAddr();
		System.out.println("doGet() is called from " + clientAddress + " by " +yourName);
		pw.println("Welcome User : " + yourName + ", " + GreetMsg);
		pw.println("Your IP address is " + clientAddress);
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doPost() called..");
		doGet(request, response);
	}

}
